package arthur.kim.stickysession;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StickySessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
